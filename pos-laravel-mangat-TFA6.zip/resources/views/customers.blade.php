<!DOCTYPE html>
<html>

<head>
    <title>Customer Accounts</title>
</head>

<body>

    <nav>
        <a href="/">Home</a> |
        <a href="/about">About</a> |
        <a href="/customers">Customers</a> |
        <a href="/users">Users</a>
    </nav>

    <h1>Customer Accounts</h1>

    @foreach ($customers as $customer)

        <div>
            <h2>{{ $customer->full_name }}</h2>

            <p>
                Email: {{ $customer->email }}<br>
                Phone: {{ $customer->phone }}
            </p>
        </div>

        <hr>

    @endforeach

</body>

</html>
