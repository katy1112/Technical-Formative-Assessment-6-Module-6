<!DOCTYPE html>
<html>

<head>
    <title>About</title>
</head>

<body>

    <nav>
        <a href="/">Home</a> |
        <a href="/about">About</a> |
        <a href="/customers">Customers</a> |
        <a href="/users">Users</a>
    </nav>

    <h1>{{ $course }}</h1>

    <p>{{ $module }}</p>

    <p>This page is created using a Laravel controller and Blade view.</p>

</body>

</html>
