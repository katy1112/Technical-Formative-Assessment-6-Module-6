<!DOCTYPE html>
<html>

<head>
    <title>Jeremy Joseph Laravel POS</title>
</head>

<body>

    <nav>
        <a href="/">Home</a> |
        <a href="/about">About</a> |
        <a href="/customers">Customers</a> |
        <a href="/users">Users</a>
    </nav>

    <h1>Welcome to Jeremy Joseph's Laravel POS</h1>

    <p>This is the landing page of my Laravel application.</p>

</body>

</html>
