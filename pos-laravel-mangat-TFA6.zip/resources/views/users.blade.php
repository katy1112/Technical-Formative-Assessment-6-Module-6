<!DOCTYPE html>
<html>

<head>
    <title>User Accounts</title>
</head>

<body>

    <nav>
        <a href="/">Home</a> |
        <a href="/about">About</a> |
        <a href="/customers">Customers</a> |
        <a href="/users">Users</a>
    </nav>

    <h1>User Accounts</h1>

    @foreach ($users as $user)

        <div>
            <h2>{{ $user->full_name }}</h2>

            <p>
                Username: {{ $user->username }}
            </p>
        </div>

        <hr>

    @endforeach

</body>

</html>
