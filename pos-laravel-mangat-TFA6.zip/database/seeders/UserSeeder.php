<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class UserSeeder extends Seeder
{
    public function run(): void
    {
        DB::table('users')->insert([
            [
                'username' => 'jeremy.joseph',
                'full_name' => 'Jeremy Joseph',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'username' => 'andrew.smith',
                'full_name' => 'Andrew Smith',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'username' => 'laura.garcia',
                'full_name' => 'Laura Garcia',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'username' => 'matthew.davis',
                'full_name' => 'Matthew Davis',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'username' => 'sarah.wilson',
                'full_name' => 'Sarah Wilson',
                'created_at' => now(),
                'updated_at' => now(),
            ],
        ]);
    }
}
