<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CustomerSeeder extends Seeder
{
    public function run(): void
    {
        DB::table('customers')->insert([
            [
                'full_name' => 'Brian Santos',
                'email' => 'brian.santos@example.com',
                'phone' => '0917 394 6258',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'full_name' => 'Rachel Mendoza',
                'email' => 'rachel.mendoza@example.com',
                'phone' => '0928 517 3642',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'full_name' => 'Christopher Reyes',
                'email' => 'christopher.reyes@example.com',
                'phone' => '0919 628 4517',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'full_name' => 'Nicole Fernandez',
                'email' => 'nicole.fernandez@example.com',
                'phone' => '0920 743 5168',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'full_name' => 'Patrick Cruz',
                'email' => 'patrick.cruz@example.com',
                'phone' => '0918 652 4731',
                'created_at' => now(),
                'updated_at' => now(),
            ],
        ]);
    }
}
